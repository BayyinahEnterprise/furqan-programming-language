"""Furqan checker layer — public entry points for each primitive's checker."""

from .bismillah import (
    PRIMITIVE_NAME as BISMILLAH_PRIMITIVE_NAME,
    check_module as check_bismillah,
    check_module_strict as check_bismillah_strict,
)
from .zahir_batin import (
    PRIMITIVE_NAME as ZAHIR_BATIN_PRIMITIVE_NAME,
    VERIFY_FUNCTION_NAME,
    check_module as check_zahir_batin,
    check_module_strict as check_zahir_batin_strict,
)
from .additive import (
    PRIMITIVE_NAME as ADDITIVE_ONLY_PRIMITIVE_NAME,
    Result as AdditiveOnlyResult,
    check_additive,
    check_module as check_additive_module,
    check_module_strict as check_additive_module_strict,
)
from .incomplete import (
    PRIMITIVE_NAME as SCAN_INCOMPLETE_PRIMITIVE_NAME,
    REQUIRED_INCOMPLETE_FIELDS,
    INTEGRITY_TYPE_NAME,
    INCOMPLETE_TYPE_NAME,
    check_incomplete,
    check_incomplete_strict,
)
from .mizan import (
    PRIMITIVE_NAME as MIZAN_PRIMITIVE_NAME,
    REQUIRED_MIZAN_FIELDS,
    check_mizan,
    check_mizan_strict,
)

__all__ = [
    # Bismillah scope (Phase 2.3)
    "BISMILLAH_PRIMITIVE_NAME",
    "check_bismillah",
    "check_bismillah_strict",
    # Zahir/batin (Phase 2.4)
    "ZAHIR_BATIN_PRIMITIVE_NAME",
    "VERIFY_FUNCTION_NAME",
    "check_zahir_batin",
    "check_zahir_batin_strict",
    # Additive-only module (Phase 2.5)
    "ADDITIVE_ONLY_PRIMITIVE_NAME",
    "AdditiveOnlyResult",
    "check_additive",
    "check_additive_module",
    "check_additive_module_strict",
    # Scan-incomplete (Phase 2.6)
    "SCAN_INCOMPLETE_PRIMITIVE_NAME",
    "REQUIRED_INCOMPLETE_FIELDS",
    "INTEGRITY_TYPE_NAME",
    "INCOMPLETE_TYPE_NAME",
    "check_incomplete",
    "check_incomplete_strict",
    # Mizan well-formedness (Phase 2.7)
    "MIZAN_PRIMITIVE_NAME",
    "REQUIRED_MIZAN_FIELDS",
    "check_mizan",
    "check_mizan_strict",
]
