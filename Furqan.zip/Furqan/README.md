# Furqan

> *Bismillah ar-Rahman ar-Rahim.*
>
> *"Blessed is He who sent down the Furqan upon His servant that he may be to the worlds a warner."* — Al-Furqan 25:1

A programming-language type-checker that enforces structural honesty
at compile time. Phase 2 (this repository) is the prototype
type-checker — not a full compiler. It demonstrates that the
Furqan thesis paper's primitive type rules are mechanically
implementable.

**Current version: `v0.5.0` — five of seven primitives shipped.**
**219 tests passing in ~0.3s.** Zero runtime dependencies (Python
stdlib only).

## What this repository is

A standalone Python type-checker that verifies a minimal subset of
the Furqan surface syntax against the paper's structural-honesty
primitives. Phase 2 is delivering them in Tanzil order:

| # | Primitive             | Module                       | Status                                      |
|---|-----------------------|------------------------------|---------------------------------------------|
| 1 | Bismillah scope       | `checker/bismillah.py`       | **Shipped** — Session 1.0 (v0.1.0)          |
| 2 | Zahir / batin         | `checker/zahir_batin.py`     | **Shipped** — Session 1.3 (v0.2.0)          |
| 3 | Additive-only modules | `checker/additive.py`        | **Shipped** — Session 1.4 (v0.3.0)          |
| 4 | Scan-incomplete       | `checker/incomplete.py`      | **Shipped** — Session 1.5 (v0.4.0)          |
| 5 | Mizan calibration     | `checker/mizan.py`           | **Shipped** — Session 1.6 (v0.5.0)          |
| 6 | Tanzil build ordering | `checker/tanzil.py`          | next                                        |
| 7 | Ring-close            | `checker/ring_close.py`      | next                                        |

Each row's "Session" entry corresponds to a single closing
`HANDOFF.md` block; each "version" entry is the corresponding
`CHANGELOG.md` minor-version bump that registers the source-language
additions.

## What this repository is not

* A full compiler (Phase 3).
* A transpiler to Rust / TypeScript / Python (Phase 3).
* An IDE plugin or session-protocol enforcer (Phase 4).
* A controlled developer study (Phase 5).
* A runtime — Furqan in Phase 2 is **static structural verification
  only**. The checker parses, walks the AST, and verifies declared
  scope against referenced symbols. It does not evaluate.

## Empirical foundation

Bayyinah v1.1.1 is the empirical anchor. Every Furqan primitive in
this checker corresponds to a behavioural convention that was
validated through Bayyinah's own development before being formalized
as a language feature. See `docs/NAMING.md` and the thesis paper for
the mapping.

## Quick start

```bash
pip install -e '.[dev]'
pytest
```

```python
import furqan
from furqan.parser import parse
from furqan.checker.mizan import check_mizan

print(furqan.__version__)   # '0.5.0'

src = '''
bismillah Demo {
    authority: NAMING_MD
    serves: purpose_hierarchy.balance_for_living_systems
    scope: calibrate
    not_scope: nothing_excluded
}

mizan detection_threshold {
    la_tatghaw:  false_positive_rate < 0.05
    la_tukhsiru: detection_rate > 0.90
    bil_qist:    calibrate(corpus, paired_fixtures)
}
'''
module = parse(src, file="demo.furqan")
assert check_mizan(module) == []   # well-formed mizan block
```

## Documents

* **Furqan thesis paper v1.0** — primitive semantics, the authoritative
  reference (Ashraf & Arfeen, 2026). Canonical location: Zenodo (DOI
  to be added on publication). The repo does not bundle the paper
  PDF; pin a reading copy alongside this checkout if needed.
* `docs/NAMING.md` — naming discipline.
* `docs/CONTRIBUTING.md` — governance protocol, compliance states,
  the five-step workflow, and §8 the polish-patch protocol.
* `docs/internals/LEXER.md` — tokenizer design notes.
* `docs/internals/CHECKER.md` — checker-layer design notes.
* `CHANGELOG.md` — per-version delta record (Bayyinah-style isnad).
* `HANDOFF.md` — per-session rolling record of what shipped, what
  was attempted, what is next.

## License

Apache 2.0 — see [LICENSE](./LICENSE).

---

*Bismillah.*
